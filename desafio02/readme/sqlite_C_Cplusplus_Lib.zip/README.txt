Tools > Compiler Options.. > Add the folling commands when calling the linker:

Copy and cole: -lsqlite3